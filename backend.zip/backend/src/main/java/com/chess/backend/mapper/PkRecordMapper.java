package com.chess.backend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chess.backend.pojo.Pkrecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PkRecordMapper extends BaseMapper<Pkrecord> {
}
