<template>
    <CardBase>
        404
    </CardBase>
</template>

<script>
import CardBase from '@/components/CardBase.vue';

export default{
    name:"NoFoundView",
    components:{
        CardBase
    }
}
</script>

<style scoped>
</style>