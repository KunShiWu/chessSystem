<template>
    <CardBase>
        我的主页
    </CardBase>
</template>

<script>
import CardBase from '@/components/CardBase.vue';

export default{
    name:"HomeView",
    components:{
        CardBase
    }
}
</script>

<style scoped>
</style>